-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2016 at 08:44 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `persediaan_barang`
--
CREATE DATABASE IF NOT EXISTS `persediaan_barang` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `persediaan_barang`;

-- --------------------------------------------------------

--
-- Table structure for table `brg_barang`
--

CREATE TABLE IF NOT EXISTS `brg_barang` (
  `Kode_Barang` varchar(15) NOT NULL DEFAULT '',
  `Tanggal` datetime DEFAULT NULL,
  `barcode` varchar(15) DEFAULT NULL,
  `Kode_Produk` varchar(11) DEFAULT NULL,
  `Nama_Barang` varchar(225) DEFAULT NULL,
  `Satuan` varchar(15) DEFAULT NULL,
  `Harga_beli` int(11) DEFAULT NULL,
  `Harga_jual` int(11) DEFAULT NULL,
  `prs_markup` smallint(6) DEFAULT NULL,
  `Stok` smallint(6) DEFAULT NULL,
  `Jml_Beli` smallint(6) DEFAULT NULL,
  `Jml_Jual` smallint(6) DEFAULT NULL,
  `Discound` int(11) DEFAULT NULL,
  `Stok_Akhir` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`Kode_Barang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `brg_barang`
--

TRUNCATE TABLE `brg_barang`;
--
-- Dumping data for table `brg_barang`
--

INSERT INTO `brg_barang` (`Kode_Barang`, `Tanggal`, `barcode`, `Kode_Produk`, `Nama_Barang`, `Satuan`, `Harga_beli`, `Harga_jual`, `prs_markup`, `Stok`, `Jml_Beli`, `Jml_Jual`, `Discound`, `Stok_Akhir`) VALUES
('LRT.001', NULL, '8993176110074', 'LRT.001.001', 'MAGIC COM KECIL', 'PCS', 320000, 420000, 0, 9, 0, 0, NULL, 0),
('LRT.002', NULL, '8886008101336', 'LRT.001.001', 'magic com besar', 'Biji', 450000, 550000, 0, 9, 0, 0, NULL, 0),
('PRT.001', NULL, '873556363655', 'PRT.001.001', 'PHILIPS 5 W', 'PCS', 25000, 30000, 0, 8, 0, 0, NULL, 0),
('PRT.002', NULL, '4242424242424', 'PRT.001.001', 'PHILIP 25 W', 'PCS', 25000, 35000, 0, 33, 0, 0, NULL, 0),
('LAL.001', NULL, '8993175531894', 'LAL.001.001', 'LAMPU 5W', 'PCS', 15000, 20000, 0, 9, 0, 0, NULL, 0),
('PRT.003', NULL, '8993118934027', 'PRT.001.001', 'PHILIP 10 W', 'PCS', 20000, 23000, 0, 13, 0, 0, NULL, 0),
('LAL.002', NULL, '234867763777', 'LAL.001.001', 'LAMPU 15W', 'PCS', 25000, 35000, 0, 11, NULL, NULL, NULL, NULL),
('PRT.004', NULL, '123456789012', '', 'PHILIP 50W NEON', 'PCS', 25000, 30000, 0, 21, NULL, NULL, NULL, NULL),
('LAL.003', NULL, '111111111111', '', 'PPPP', 'PCS', 12000, 20000, 0, 18, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brg_golongan`
--

CREATE TABLE IF NOT EXISTS `brg_golongan` (
  `Kode_Golongan` varchar(3) DEFAULT NULL,
  `Nama_Golongan` varchar(60) DEFAULT NULL,
  `Keterangan` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `brg_golongan`
--

TRUNCATE TABLE `brg_golongan`;
--
-- Dumping data for table `brg_golongan`
--

INSERT INTO `brg_golongan` (`Kode_Golongan`, `Nama_Golongan`, `Keterangan`) VALUES
('LRT', 'LISTRIK RUMAH TANGGA', 'PERALATAN LISTRIK RUMAH TANGGA'),
('LAL', 'LISTRIK ARUS LEMAH', 'PERALATAN LISTRIK UNTUK ARUS LEMAH'),
('PRT', 'PERALATAN RUMAH TANGGA', '');

-- --------------------------------------------------------

--
-- Table structure for table `brg_jenis`
--

CREATE TABLE IF NOT EXISTS `brg_jenis` (
  `Kode_Jenis` varchar(7) DEFAULT NULL,
  `Kode_Golongan` varchar(3) DEFAULT NULL,
  `Nama_Jenis` varchar(50) DEFAULT NULL,
  `Keterangan` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `brg_jenis`
--

TRUNCATE TABLE `brg_jenis`;
--
-- Dumping data for table `brg_jenis`
--

INSERT INTO `brg_jenis` (`Kode_Jenis`, `Kode_Golongan`, `Nama_Jenis`, `Keterangan`) VALUES
('CTM.001', 'CTM', 'CAT ACRYLIC', '-'),
('CTM.002', 'CTM', 'CATYLAC', '-'),
('LRT.001', 'LRT', 'PERLENGKAPAN DAPUR', ''),
('LRT.002', 'LRT', 'PERLENGKAPAN INSTALLASI', ''),
('PRT.001', 'PRT', 'LAMPU DAPUR', 'LAMPU DAPUR'),
('LAL.001', 'LAL', 'PERLENGKAPAN ARUS LEMAH', 'PERLENGKAPAN ARUS LEMAH');

-- --------------------------------------------------------

--
-- Table structure for table `brg_produk`
--

CREATE TABLE IF NOT EXISTS `brg_produk` (
  `Kode_Produk` varchar(11) DEFAULT NULL,
  `Kode_Jenis` varchar(7) DEFAULT NULL,
  `Nama_Produk` varchar(60) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `brg_produk`
--

TRUNCATE TABLE `brg_produk`;
--
-- Dumping data for table `brg_produk`
--

INSERT INTO `brg_produk` (`Kode_Produk`, `Kode_Jenis`, `Nama_Produk`) VALUES
('CTM.002.001', 'CTM.002', 'CATYLAC'),
('CTM.001.001', 'CTM.001', 'CRYLIC'),
('LRT.001.001', 'LRT.001', 'MIYAKO'),
('LRT.001.002', 'LRT.001', 'CHANG HONG'),
('PRT.001.001', 'PRT.001', 'PHILIPS'),
('LAL.001.001', 'LAL.001', 'PHILIPS');

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE IF NOT EXISTS `discount` (
  `Discound` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `discount`
--

TRUNCATE TABLE `discount`;
-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `Kode_Pelanggan` varchar(13) NOT NULL DEFAULT '',
  `Nama_Pelanggan` varchar(35) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `No_Telepon` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Kode_Pelanggan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pelanggan`
--

TRUNCATE TABLE `pelanggan`;
--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`Kode_Pelanggan`, `Nama_Pelanggan`, `Alamat`, `No_Telepon`) VALUES
('PL-002', 'sulastri', 'JL. kenanga', '[0257]-6636363_'),
('PL-003', 'iwan', 'JL. manggis', '[0525]-2666626_'),
('PL-004', 'poniman', 'jl. mangga', '[0813]-25678999'),
('PL-005', 'indra lesmana', 'jl. abc', '[024_]-67888999'),
('PL-006', 'KUSUMA', 'JL. WARU', '[0816]-76666666'),
('PL-007', 'CONTOH 7', 'JL. CONTOH 7', '[024_]-888888__');

-- --------------------------------------------------------

--
-- Table structure for table `pemasok`
--

CREATE TABLE IF NOT EXISTS `pemasok` (
  `Kode_Pemasok` varchar(6) DEFAULT NULL,
  `Nama_Pemasok` varchar(35) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `No_Telepon` varchar(15) DEFAULT NULL,
  `KontakP` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pemasok`
--

TRUNCATE TABLE `pemasok`;
--
-- Dumping data for table `pemasok`
--

INSERT INTO `pemasok` (`Kode_Pemasok`, `Nama_Pemasok`, `Alamat`, `No_Telepon`, `KontakP`) VALUES
('PS-001', 'CV. MERDEKA', 'JL. ABC', '[0244]-88884848', 'SURYA'),
('PS-002', 'CV. ANDALAN PERKASA', 'JL. MANDALA', '[0124]-555554__', 'SUGITO');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE IF NOT EXISTS `pembelian` (
  `No_Masuk` varchar(10) NOT NULL DEFAULT '',
  `Tgl_Masuk` datetime DEFAULT NULL,
  `No_Pesan` varchar(10) DEFAULT NULL,
  `Total` int(100) DEFAULT NULL,
  `UserId` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`No_Masuk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pembelian`
--

TRUNCATE TABLE `pembelian`;
--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`No_Masuk`, `Tgl_Masuk`, `No_Pesan`, `Total`, `UserId`) VALUES
('BL-0000001', '2016-04-08 00:00:00', 'PB-0000001', 40000, 'RUDI');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_detail`
--

CREATE TABLE IF NOT EXISTS `pembelian_detail` (
  `No_Masuk` varchar(10) DEFAULT NULL,
  `Kode_Barang` varchar(15) DEFAULT NULL,
  `Harga_Beli` int(11) DEFAULT NULL,
  `Jumlah` smallint(6) DEFAULT NULL,
  `SubTotal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pembelian_detail`
--

TRUNCATE TABLE `pembelian_detail`;
--
-- Dumping data for table `pembelian_detail`
--

INSERT INTO `pembelian_detail` (`No_Masuk`, `Kode_Barang`, `Harga_Beli`, `Jumlah`, `SubTotal`) VALUES
('BL-0000001', 'LAL.001', 15000, 1, 15000),
('BL-0000001', 'LAL.002', 25000, 1, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE IF NOT EXISTS `pengguna` (
  `UserId` varchar(30) NOT NULL DEFAULT '',
  `PassId` varchar(30) DEFAULT NULL,
  `Nama` varchar(30) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pengguna`
--

TRUNCATE TABLE `pengguna`;
--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`UserId`, `PassId`, `Nama`, `Status`) VALUES
('INDRA', 'INDRA', 'INDRA LESMANA', 'GUDANG'),
('RUDI', 'RUDI', 'RUDI SUPRIO', 'PEMILIK'),
('NINGSIH', 'NINGSIH', 'NINGSIH YULIASARI', 'KASIR'),
('SAPTOTO', 'SAPTOTO', 'RUDIANA SAPTOTO', 'GUDANG'),
('JOKO12', 'JOKO', 'JOKO WASESO', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE IF NOT EXISTS `penjualan` (
  `No_Nota` varchar(25) NOT NULL DEFAULT '',
  `Tgl_Nota` datetime DEFAULT NULL,
  `Potongan` decimal(19,4) DEFAULT NULL,
  `Jasa` decimal(19,4) DEFAULT NULL,
  `Jumlah_Bayar` decimal(19,4) DEFAULT NULL,
  `Kode_Pelanggan` varchar(13) DEFAULT NULL,
  `UserId` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`No_Nota`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `penjualan`
--

TRUNCATE TABLE `penjualan`;
--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`No_Nota`, `Tgl_Nota`, `Potongan`, `Jasa`, `Jumlah_Bayar`, `Kode_Pelanggan`, `UserId`) VALUES
('RUDI-0000001', '2016-03-08 00:00:00', '0.0000', '58500.0000', '643500.0000', ' ', 'RUDI'),
('RUDI-0000002', '2016-03-08 00:00:00', '0.0000', '6000.0000', '66000.0000', ' ', 'RUDI'),
('RUDI-0000003', '2016-03-09 00:00:00', '0.0000', '4600.0000', '50600.0000', 'ASIH ', 'RUDI'),
('RUDI-0000004', '2016-03-14 00:00:00', '0.0000', '3000.0000', '30000.0000', ' ', 'RUDI'),
('RUDI-0000005', '2016-03-14 00:00:00', '0.0000', '3500.0000', '35000.0000', ' ', 'RUDI'),
('RUDI-0000006', '2016-03-14 00:00:00', '0.0000', '2300.0000', '23000.0000', ' ', 'RUDI'),
('RUDI-0000007', '2016-03-14 00:00:00', '0.0000', '42000.0000', '420000.0000', ' ', 'RUDI'),
('RUDI-0000008', '2016-03-14 00:00:00', '0.0000', '55000.0000', '550000.0000', ' ', 'RUDI'),
('RUDI-0000009', '2016-03-14 00:00:00', '0.0000', '4000.0000', '40000.0000', ' ', 'RUDI'),
('RUDI-0000010', '2016-03-16 00:00:00', '0.0000', '3500.0000', '35000.0000', '', 'RUDI'),
('RUDI-0000011', '2016-03-22 00:00:00', '0.0000', '6000.0000', '60000.0000', 'PL-003', 'RUDI'),
('RUDI-0000012', '2016-03-22 00:00:00', '0.0000', '6000.0000', '60000.0000', 'PL-002', 'RUDI'),
('RUDI-0000013', '2016-03-22 00:00:00', '0.0000', '6300.0000', '63000.0000', 'PL-005', 'RUDI');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan_detail`
--

CREATE TABLE IF NOT EXISTS `penjualan_detail` (
  `No_Nota` varchar(25) DEFAULT NULL,
  `Kode_Barang` varchar(15) DEFAULT NULL,
  `Harga_Jual` int(10) DEFAULT NULL,
  `Jumlah` int(11) DEFAULT NULL,
  `Potongan` int(10) DEFAULT NULL,
  `Subtotal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `penjualan_detail`
--

TRUNCATE TABLE `penjualan_detail`;
--
-- Dumping data for table `penjualan_detail`
--

INSERT INTO `penjualan_detail` (`No_Nota`, `Kode_Barang`, `Harga_Jual`, `Jumlah`, `Potongan`, `Subtotal`) VALUES
('RUDI-0000001', 'PRT.001.001.002', 35000, 1, 0, 35000),
('RUDI-0000001', 'LRT.001.001.002', 550000, 1, 0, 550000),
('RUDI-0000002', 'PRT.001.001.001', 30000, 2, 0, 60000),
('RUDI-0000003', 'PRT.001.001.003', 23000, 2, 0, 46000),
('RUDI-0000004', 'PRT.001.001.001', 30000, 1, 0, 30000),
('RUDI-0000005', 'PRT.001.001.002', 35000, 1, 0, 35000),
('RUDI-0000006', 'PRT.001.001.003', 23000, 1, 0, 23000),
('RUDI-0000007', 'LRT.001.001.001', 420000, 1, 0, 420000),
('RUDI-0000008', 'LRT.001.001.002', 550000, 1, 0, 550000),
('RUDI-0000009', 'LAL.001.001.001', 20000, 2, 0, 40000),
('RUDI-0000010', 'PRT.001.001.002', 35000, 1, 0, 35000),
('RUDI-0000012', 'PRT.004', 30000, 2, 0, 60000),
('RUDI-0000013', 'LAL.003', 20000, 2, 0, 40000),
('RUDI-0000013', 'PRT.003', 23000, 1, 0, 23000);

-- --------------------------------------------------------

--
-- Table structure for table `pesanan_pembelian`
--

CREATE TABLE IF NOT EXISTS `pesanan_pembelian` (
  `No_Pesan` varchar(10) NOT NULL DEFAULT '',
  `Tgl_Pesan` date DEFAULT NULL,
  `Kode_Pemasok` varchar(6) DEFAULT NULL,
  `Total` int(100) DEFAULT NULL,
  `UserId` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`No_Pesan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pesanan_pembelian`
--

TRUNCATE TABLE `pesanan_pembelian`;
--
-- Dumping data for table `pesanan_pembelian`
--

INSERT INTO `pesanan_pembelian` (`No_Pesan`, `Tgl_Pesan`, `Kode_Pemasok`, `Total`, `UserId`) VALUES
('PB-0000001', '2016-04-08', 'PS-001', 40000, 'RUDI');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan_pembelian_detail`
--

CREATE TABLE IF NOT EXISTS `pesanan_pembelian_detail` (
  `No_Pesan` varchar(10) DEFAULT NULL,
  `Kode_Barang` varchar(15) DEFAULT NULL,
  `Harga_Beli` int(11) DEFAULT NULL,
  `Jumlah` smallint(6) DEFAULT NULL,
  `SubTotal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `pesanan_pembelian_detail`
--

TRUNCATE TABLE `pesanan_pembelian_detail`;
--
-- Dumping data for table `pesanan_pembelian_detail`
--

INSERT INTO `pesanan_pembelian_detail` (`No_Pesan`, `Kode_Barang`, `Harga_Beli`, `Jumlah`, `SubTotal`) VALUES
('PB-0000001', 'LAL.001', 15000, 1, 15000),
('PB-0000001', 'LAL.002', 25000, 1, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `KD_SALES` tinytext,
  `NAMASALES` tinytext,
  `ALAMAT` tinytext,
  `NOTELP` tinytext,
  `HARI` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `sales`
--

TRUNCATE TABLE `sales`;
--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`KD_SALES`, `NAMASALES`, `ALAMAT`, `NOTELP`, `HARI`) VALUES
('SL-001', 'SUTRIS', 'JL. BALEBON RAYA NO. 13A RT 001/004, SEMARANG', '[0856]-42488479', 'SELASA'),
('SL-002', 'DENY', 'JL. MANGUNHARJO RT 001/002, TEMBALANG', '[0877]-32123456', 'KAMIS');

-- --------------------------------------------------------

--
-- Table structure for table `setoran`
--

CREATE TABLE IF NOT EXISTS `setoran` (
  `no_faktur` tinytext,
  `tanggal` tinytext,
  `nota_pesan` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `setoran`
--

TRUNCATE TABLE `setoran`;
-- --------------------------------------------------------

--
-- Table structure for table `stok_opname`
--

CREATE TABLE IF NOT EXISTS `stok_opname` (
  `id_stok` int(11) NOT NULL,
  `Tanggal` datetime DEFAULT NULL,
  `Kode_Barang` varchar(15) DEFAULT NULL,
  `Qty_Masuk` smallint(6) DEFAULT NULL,
  `Harga_Beli` double DEFAULT NULL,
  `Qty_Keluar` smallint(6) DEFAULT NULL,
  `Harga_Jual` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `stok_opname`
--

TRUNCATE TABLE `stok_opname`;
--
-- Dumping data for table `stok_opname`
--

INSERT INTO `stok_opname` (`id_stok`, `Tanggal`, `Kode_Barang`, `Qty_Masuk`, `Harga_Beli`, `Qty_Keluar`, `Harga_Jual`) VALUES
(2, '2014-07-11 00:00:00', 'CTM.001.001.001', 10, 40000, 0, 0),
(3, '2014-07-11 00:00:00', 'CTM.001.001.002', 10, 230000, 0, 0),
(4, '2014-07-11 00:00:00', 'CTM.002.001.001', 10, 35000, 0, 0),
(5, '2014-08-11 00:00:00', 'CTM.002.001.001', 0, 0, 2, 45000),
(6, '2014-08-11 00:00:00', 'CTM.001.001.001', 0, 0, 2, 55000),
(7, '2016-08-03 00:00:00', 'PRT.001.001.001', 1, 25000, 0, 0),
(8, '2016-08-03 00:00:00', 'LRT.001.001.002', 1, 450000, 0, 0),
(9, '2016-08-03 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000),
(10, '2016-08-03 00:00:00', 'LRT.001.001.002', 0, 0, 1, 550000),
(11, '2016-08-03 00:00:00', 'PRT.001.001.002', 25, 25000, 0, 0),
(12, '2016-08-03 00:00:00', 'PRT.001.001.001', 0, 0, 2, 30000),
(13, '2016-09-03 00:00:00', 'PRT.001.001.003', 5, 20000, 0, 0),
(14, '2016-09-03 00:00:00', 'PRT.001.001.003', 2, 20000, 0, 0),
(15, '2016-09-03 00:00:00', 'PRT.001.001.003', 0, 0, 2, 23000),
(16, '2016-03-14 00:00:00', 'PRT.001.001.001', 0, 0, 1, 30000),
(17, '2016-03-14 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000),
(18, '2016-03-14 00:00:00', 'PRT.001.001.003', 0, 0, 1, 23000),
(19, '2016-03-14 00:00:00', 'LRT.001.001.001', 0, 0, 1, 420000),
(20, '2016-03-14 00:00:00', 'LRT.001.001.002', 0, 0, 1, 550000),
(21, '2016-03-14 00:00:00', 'LAL.001.001.001', 0, 0, 2, 20000),
(22, '1900-01-01 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000),
(0, '2016-03-22 00:00:00', 'PRT.004', 1, 25000, 0, 0),
(0, '2016-03-22 00:00:00', 'PRT.002', 1, 25000, 0, 0),
(0, '2016-03-22 00:00:00', 'PRT.004', 0, 0, 32767, 30000),
(0, '2016-03-22 00:00:00', 'PRT.004', 12, 25000, 0, 0),
(0, '2016-03-22 00:00:00', 'LAL.003', 10, 12000, 0, 0),
(0, '2016-03-22 00:00:00', 'LAL.003', 0, 0, 32767, 20000),
(0, '2016-03-22 00:00:00', 'PRT.003', 0, 0, 23000, 23000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
