-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 22, 2016 at 03:47 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `persediaan_barang`
-- 
CREATE DATABASE `persediaan_barang` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `persediaan_barang`;

-- --------------------------------------------------------

-- 
-- Table structure for table `brg_barang`
-- 

CREATE TABLE `brg_barang` (
  `Kode_Barang` varchar(15) NOT NULL default '',
  `Tanggal` datetime default NULL,
  `barcode` varchar(15) default NULL,
  `Kode_Produk` varchar(11) default NULL,
  `Nama_Barang` varchar(225) default NULL,
  `Satuan` varchar(15) default NULL,
  `Harga_beli` int(11) default NULL,
  `Harga_jual` int(11) default NULL,
  `prs_markup` smallint(6) default NULL,
  `Stok` smallint(6) default NULL,
  `Jml_Beli` smallint(6) default NULL,
  `Jml_Jual` smallint(6) default NULL,
  `Discound` int(11) default NULL,
  `Stok_Akhir` smallint(6) default NULL,
  PRIMARY KEY  (`Kode_Barang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `brg_barang`
-- 

INSERT INTO `brg_barang` VALUES ('LRT.001', NULL, '8993176110074', 'LRT.001.001', 'MAGIC COM KECIL', 'PCS', 320000, 420000, 0, 9, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('LRT.002', NULL, '8886008101336', 'LRT.001.001', 'magic com besar', 'Biji', 450000, 550000, 0, 9, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('PRT.001', NULL, '873556363655', 'PRT.001.001', 'PHILIPS 5 W', 'PCS', 25000, 30000, 0, 8, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('PRT.002', NULL, '4242424242424', 'PRT.001.001', 'PHILIP 25 W', 'PCS', 25000, 35000, 0, 33, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('LAL.001', NULL, '8993175531894', 'LAL.001.001', 'LAMPU 5W', 'PCS', 15000, 20000, 0, 8, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('PRT.003', NULL, '8993118934027', 'PRT.001.001', 'PHILIP 10 W', 'PCS', 20000, 23000, 0, 13, 0, 0, NULL, 0);
INSERT INTO `brg_barang` VALUES ('LAL.002', NULL, '234867763777', 'LAL.001.001', 'LAMPU 15W', 'PCS', 25000, 35000, 0, 10, NULL, NULL, NULL, NULL);
INSERT INTO `brg_barang` VALUES ('PRT.004', NULL, '123456789012', '', 'PHILIP 50W NEON', 'PCS', 25000, 30000, 0, 21, NULL, NULL, NULL, NULL);
INSERT INTO `brg_barang` VALUES ('LAL.003', NULL, '111111111111', '', 'PPPP', 'PCS', 12000, 20000, 0, 18, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `brg_golongan`
-- 

CREATE TABLE `brg_golongan` (
  `Kode_Golongan` varchar(3) default NULL,
  `Nama_Golongan` varchar(60) default NULL,
  `Keterangan` varchar(150) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `brg_golongan`
-- 

INSERT INTO `brg_golongan` VALUES ('LRT', 'LISTRIK RUMAH TANGGA', 'PERALATAN LISTRIK RUMAH TANGGA');
INSERT INTO `brg_golongan` VALUES ('LAL', 'LISTRIK ARUS LEMAH', 'PERALATAN LISTRIK UNTUK ARUS LEMAH');
INSERT INTO `brg_golongan` VALUES ('PRT', 'PERALATAN RUMAH TANGGA', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `brg_jenis`
-- 

CREATE TABLE `brg_jenis` (
  `Kode_Jenis` varchar(7) default NULL,
  `Kode_Golongan` varchar(3) default NULL,
  `Nama_Jenis` varchar(50) default NULL,
  `Keterangan` varchar(150) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `brg_jenis`
-- 

INSERT INTO `brg_jenis` VALUES ('CTM.001', 'CTM', 'CAT ACRYLIC', '-');
INSERT INTO `brg_jenis` VALUES ('CTM.002', 'CTM', 'CATYLAC', '-');
INSERT INTO `brg_jenis` VALUES ('LRT.001', 'LRT', 'PERLENGKAPAN DAPUR', '');
INSERT INTO `brg_jenis` VALUES ('LRT.002', 'LRT', 'PERLENGKAPAN INSTALLASI', '');
INSERT INTO `brg_jenis` VALUES ('PRT.001', 'PRT', 'LAMPU DAPUR', 'LAMPU DAPUR');
INSERT INTO `brg_jenis` VALUES ('LAL.001', 'LAL', 'PERLENGKAPAN ARUS LEMAH', 'PERLENGKAPAN ARUS LEMAH');

-- --------------------------------------------------------

-- 
-- Table structure for table `brg_produk`
-- 

CREATE TABLE `brg_produk` (
  `Kode_Produk` varchar(11) default NULL,
  `Kode_Jenis` varchar(7) default NULL,
  `Nama_Produk` varchar(60) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `brg_produk`
-- 

INSERT INTO `brg_produk` VALUES ('CTM.002.001', 'CTM.002', 'CATYLAC');
INSERT INTO `brg_produk` VALUES ('CTM.001.001', 'CTM.001', 'CRYLIC');
INSERT INTO `brg_produk` VALUES ('LRT.001.001', 'LRT.001', 'MIYAKO');
INSERT INTO `brg_produk` VALUES ('LRT.001.002', 'LRT.001', 'CHANG HONG');
INSERT INTO `brg_produk` VALUES ('PRT.001.001', 'PRT.001', 'PHILIPS');
INSERT INTO `brg_produk` VALUES ('LAL.001.001', 'LAL.001', 'PHILIPS');

-- --------------------------------------------------------

-- 
-- Table structure for table `discount`
-- 

CREATE TABLE `discount` (
  `Discound` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `discount`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `pelanggan`
-- 

CREATE TABLE `pelanggan` (
  `Kode_Pelanggan` varchar(13) default NULL,
  `Nama_Pelanggan` varchar(35) default NULL,
  `Alamat` varchar(100) default NULL,
  `No_Telepon` varchar(15) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pelanggan`
-- 

INSERT INTO `pelanggan` VALUES ('PL-002', 'sulastri', 'JL. kenanga', '[0257]-6636363_');
INSERT INTO `pelanggan` VALUES ('PL-003', 'iwan', 'JL. manggis', '[0525]-2666626_');
INSERT INTO `pelanggan` VALUES ('PL-004', 'poniman', 'jl. mangga', '[0813]-25678999');
INSERT INTO `pelanggan` VALUES ('PL-005', 'indra lesmana', 'jl. abc', '[024_]-67888999');
INSERT INTO `pelanggan` VALUES ('PL-006', 'KUSUMA', 'JL. WARU', '[0816]-76666666');

-- --------------------------------------------------------

-- 
-- Table structure for table `pemasok`
-- 

CREATE TABLE `pemasok` (
  `Kode_Pemasok` varchar(6) default NULL,
  `Nama_Pemasok` varchar(35) default NULL,
  `Alamat` varchar(100) default NULL,
  `No_Telepon` varchar(15) default NULL,
  `KontakP` varchar(30) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pemasok`
-- 

INSERT INTO `pemasok` VALUES ('PS-001', 'CV. MERDEKA', 'JL. ABC', '[0244]-88884848', 'SURYA');
INSERT INTO `pemasok` VALUES ('PS-002', 'CV. ANDALAN PERKASA', 'JL. MANDALA', '[0124]-555554__', 'SUGITO');

-- --------------------------------------------------------

-- 
-- Table structure for table `pembelian`
-- 

CREATE TABLE `pembelian` (
  `No_Masuk` varchar(10) NOT NULL default '',
  `Tgl_Masuk` datetime default NULL,
  `Kode_Pemasok` varchar(6) default NULL,
  `Total` int(100) default NULL,
  `UserId` varchar(30) default NULL,
  PRIMARY KEY  (`No_Masuk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pembelian`
-- 

INSERT INTO `pembelian` VALUES ('BL-0000001', '2014-11-07 00:00:00', 'PS-005', 3050000, 'admin');
INSERT INTO `pembelian` VALUES ('BL-0000002', '2016-03-08 00:00:00', 'PS-001', 475000, 'RUDI');
INSERT INTO `pembelian` VALUES ('BL-0000003', '2016-03-08 00:00:00', 'PS-001', 625000, 'RUDI');
INSERT INTO `pembelian` VALUES ('BL-0000004', '2016-03-09 00:00:00', 'PS-001', 100000, 'RUDI');
INSERT INTO `pembelian` VALUES ('BL-0000005', '2016-03-09 00:00:00', 'PS-001', 40000, 'RUDI');
INSERT INTO `pembelian` VALUES ('BL-0000006', '2016-03-22 00:00:00', 'PS-001', 300000, 'RUDI');
INSERT INTO `pembelian` VALUES ('BL-0000007', '2016-03-22 00:00:00', 'PS-002', 120000, 'RUDI');

-- --------------------------------------------------------

-- 
-- Table structure for table `pembelian_detail`
-- 

CREATE TABLE `pembelian_detail` (
  `No_Masuk` varchar(10) default NULL,
  `Kode_Barang` varchar(15) default NULL,
  `Harga_Beli` int(11) default NULL,
  `Jumlah` smallint(6) default NULL,
  `SubTotal` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pembelian_detail`
-- 

INSERT INTO `pembelian_detail` VALUES ('BL-0000001', 'CTM.001.001.001', 40000, 10, 400000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000001', 'CTM.001.001.002', 230000, 10, 2300000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000001', 'CTM.002.001.001', 35000, 10, 350000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000002', 'PRT.001.001.001', 25000, 1, 25000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000002', 'LRT.001.001.002', 450000, 1, 450000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000003', 'PRT.001.001.002', 25000, 25, 625000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000004', 'PRT.001.001.003', 20000, 5, 100000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000005', 'PRT.001.001.003', 20000, 2, 40000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000002', 'PRT.004', 25000, 1, 25000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000002', 'PRT.002', 25000, 1, 25000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000006', 'PRT.004', 25000, 12, 300000);
INSERT INTO `pembelian_detail` VALUES ('BL-0000007', 'LAL.003', 12000, 10, 120000);

-- --------------------------------------------------------

-- 
-- Table structure for table `pengguna`
-- 

CREATE TABLE `pengguna` (
  `UserId` varchar(30) default NULL,
  `PassId` varchar(30) default NULL,
  `Nama` varchar(30) default NULL,
  `Status` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pengguna`
-- 

INSERT INTO `pengguna` VALUES ('INDRA', 'INDRA', 'INDRA LESMANA', 'GUDANG');
INSERT INTO `pengguna` VALUES ('RUDI', 'RUDI', 'RUDI SUPRIO', 'PEMILIK');
INSERT INTO `pengguna` VALUES ('NINGSIH', 'NINGSIH', 'NINGSIH YULIASARI', 'KASIR');
INSERT INTO `pengguna` VALUES ('SAPTOTO', 'SAPTOTO', 'RUDIANA SAPTOTO', 'GUDANG');
INSERT INTO `pengguna` VALUES ('JOKO12', 'JOKO', 'JOKO WASESO', 'ADMIN');

-- --------------------------------------------------------

-- 
-- Table structure for table `penjualan`
-- 

CREATE TABLE `penjualan` (
  `No_Nota` varchar(25) default NULL,
  `Tgl_Nota` datetime default NULL,
  `Potongan` decimal(19,4) default NULL,
  `Jasa` decimal(19,4) default NULL,
  `Jumlah_Bayar` decimal(19,4) default NULL,
  `Kode_Pelanggan` varchar(13) default NULL,
  `UserId` varchar(30) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `penjualan`
-- 

INSERT INTO `penjualan` VALUES ('RUDI-0000001', '2016-03-08 00:00:00', 0.0000, 58500.0000, 643500.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000002', '2016-03-08 00:00:00', 0.0000, 6000.0000, 66000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000003', '2016-03-09 00:00:00', 0.0000, 4600.0000, 50600.0000, 'ASIH ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000004', '2016-03-14 00:00:00', 0.0000, 3000.0000, 30000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000005', '2016-03-14 00:00:00', 0.0000, 3500.0000, 35000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000006', '2016-03-14 00:00:00', 0.0000, 2300.0000, 23000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000007', '2016-03-14 00:00:00', 0.0000, 42000.0000, 420000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000008', '2016-03-14 00:00:00', 0.0000, 55000.0000, 550000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000009', '2016-03-14 00:00:00', 0.0000, 4000.0000, 40000.0000, ' ', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000010', '2016-03-16 00:00:00', 0.0000, 3500.0000, 35000.0000, '', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000011', '2016-03-22 00:00:00', 0.0000, 6000.0000, 60000.0000, 'PL-003', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000012', '2016-03-22 00:00:00', 0.0000, 6000.0000, 60000.0000, 'PL-002', 'RUDI');
INSERT INTO `penjualan` VALUES ('RUDI-0000013', '2016-03-22 00:00:00', 0.0000, 6300.0000, 63000.0000, 'PL-005', 'RUDI');

-- --------------------------------------------------------

-- 
-- Table structure for table `penjualan_detail`
-- 

CREATE TABLE `penjualan_detail` (
  `No_Nota` varchar(25) default NULL,
  `Kode_Barang` varchar(15) default NULL,
  `Harga_Jual` int(10) default NULL,
  `Jumlah` int(11) default NULL,
  `Potongan` int(10) default NULL,
  `Subtotal` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `penjualan_detail`
-- 

INSERT INTO `penjualan_detail` VALUES ('RUDI-0000001', 'PRT.001.001.002', 35000, 1, 0, 35000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000001', 'LRT.001.001.002', 550000, 1, 0, 550000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000002', 'PRT.001.001.001', 30000, 2, 0, 60000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000003', 'PRT.001.001.003', 23000, 2, 0, 46000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000004', 'PRT.001.001.001', 30000, 1, 0, 30000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000005', 'PRT.001.001.002', 35000, 1, 0, 35000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000006', 'PRT.001.001.003', 23000, 1, 0, 23000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000007', 'LRT.001.001.001', 420000, 1, 0, 420000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000008', 'LRT.001.001.002', 550000, 1, 0, 550000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000009', 'LAL.001.001.001', 20000, 2, 0, 40000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000010', 'PRT.001.001.002', 35000, 1, 0, 35000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000012', 'PRT.004', 30000, 2, 0, 60000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000013', 'LAL.003', 20000, 2, 0, 40000);
INSERT INTO `penjualan_detail` VALUES ('RUDI-0000013', 'PRT.003', 23000, 1, 0, 23000);

-- --------------------------------------------------------

-- 
-- Table structure for table `pesanan`
-- 

CREATE TABLE `pesanan` (
  `nota_pesan` tinytext,
  `tanggal_pesan` datetime default NULL,
  `KD_SALES` tinytext,
  `Kode_Pelanggan` varchar(6) default NULL,
  `kota` tinytext,
  `hari` tinytext,
  `penerima` tinytext,
  `prepare` tinytext,
  `cekoleh` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pesanan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `pesanan_detail`
-- 

CREATE TABLE `pesanan_detail` (
  `nota_pesan` tinytext,
  `Kode_Barang` varchar(15) default NULL,
  `Jumlah` int(11) default NULL,
  `Sisa` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `pesanan_detail`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sales`
-- 

CREATE TABLE `sales` (
  `KD_SALES` tinytext,
  `NAMASALES` tinytext,
  `ALAMAT` tinytext,
  `NOTELP` tinytext,
  `HARI` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `sales`
-- 

INSERT INTO `sales` VALUES ('SL-001', 'SUTRIS', 'JL. BALEBON RAYA NO. 13A RT 001/004, SEMARANG', '[0856]-42488479', 'SELASA');
INSERT INTO `sales` VALUES ('SL-002', 'DENY', 'JL. MANGUNHARJO RT 001/002, TEMBALANG', '[0877]-32123456', 'KAMIS');

-- --------------------------------------------------------

-- 
-- Table structure for table `setoran`
-- 

CREATE TABLE `setoran` (
  `no_faktur` tinytext,
  `tanggal` tinytext,
  `nota_pesan` tinytext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `setoran`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `stok_opname`
-- 

CREATE TABLE `stok_opname` (
  `id_stok` int(11) NOT NULL,
  `Tanggal` datetime default NULL,
  `Kode_Barang` varchar(15) default NULL,
  `Qty_Masuk` smallint(6) default NULL,
  `Harga_Beli` double default NULL,
  `Qty_Keluar` smallint(6) default NULL,
  `Harga_Jual` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `stok_opname`
-- 

INSERT INTO `stok_opname` VALUES (2, '2014-07-11 00:00:00', 'CTM.001.001.001', 10, 40000, 0, 0);
INSERT INTO `stok_opname` VALUES (3, '2014-07-11 00:00:00', 'CTM.001.001.002', 10, 230000, 0, 0);
INSERT INTO `stok_opname` VALUES (4, '2014-07-11 00:00:00', 'CTM.002.001.001', 10, 35000, 0, 0);
INSERT INTO `stok_opname` VALUES (5, '2014-08-11 00:00:00', 'CTM.002.001.001', 0, 0, 2, 45000);
INSERT INTO `stok_opname` VALUES (6, '2014-08-11 00:00:00', 'CTM.001.001.001', 0, 0, 2, 55000);
INSERT INTO `stok_opname` VALUES (7, '2016-08-03 00:00:00', 'PRT.001.001.001', 1, 25000, 0, 0);
INSERT INTO `stok_opname` VALUES (8, '2016-08-03 00:00:00', 'LRT.001.001.002', 1, 450000, 0, 0);
INSERT INTO `stok_opname` VALUES (9, '2016-08-03 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000);
INSERT INTO `stok_opname` VALUES (10, '2016-08-03 00:00:00', 'LRT.001.001.002', 0, 0, 1, 550000);
INSERT INTO `stok_opname` VALUES (11, '2016-08-03 00:00:00', 'PRT.001.001.002', 25, 25000, 0, 0);
INSERT INTO `stok_opname` VALUES (12, '2016-08-03 00:00:00', 'PRT.001.001.001', 0, 0, 2, 30000);
INSERT INTO `stok_opname` VALUES (13, '2016-09-03 00:00:00', 'PRT.001.001.003', 5, 20000, 0, 0);
INSERT INTO `stok_opname` VALUES (14, '2016-09-03 00:00:00', 'PRT.001.001.003', 2, 20000, 0, 0);
INSERT INTO `stok_opname` VALUES (15, '2016-09-03 00:00:00', 'PRT.001.001.003', 0, 0, 2, 23000);
INSERT INTO `stok_opname` VALUES (16, '2016-03-14 00:00:00', 'PRT.001.001.001', 0, 0, 1, 30000);
INSERT INTO `stok_opname` VALUES (17, '2016-03-14 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000);
INSERT INTO `stok_opname` VALUES (18, '2016-03-14 00:00:00', 'PRT.001.001.003', 0, 0, 1, 23000);
INSERT INTO `stok_opname` VALUES (19, '2016-03-14 00:00:00', 'LRT.001.001.001', 0, 0, 1, 420000);
INSERT INTO `stok_opname` VALUES (20, '2016-03-14 00:00:00', 'LRT.001.001.002', 0, 0, 1, 550000);
INSERT INTO `stok_opname` VALUES (21, '2016-03-14 00:00:00', 'LAL.001.001.001', 0, 0, 2, 20000);
INSERT INTO `stok_opname` VALUES (22, '1900-01-01 00:00:00', 'PRT.001.001.002', 0, 0, 1, 35000);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'PRT.004', 1, 25000, 0, 0);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'PRT.002', 1, 25000, 0, 0);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'PRT.004', 0, 0, 32767, 30000);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'PRT.004', 12, 25000, 0, 0);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'LAL.003', 10, 12000, 0, 0);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'LAL.003', 0, 0, 32767, 20000);
INSERT INTO `stok_opname` VALUES (0, '2016-03-22 00:00:00', 'PRT.003', 0, 0, 23000, 23000);
